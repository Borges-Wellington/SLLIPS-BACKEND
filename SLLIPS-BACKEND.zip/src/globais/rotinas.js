class rotinas {
}

module.exports = new rotinas()